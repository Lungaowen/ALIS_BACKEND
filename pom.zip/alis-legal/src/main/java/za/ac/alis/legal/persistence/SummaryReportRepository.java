package za.ac.alis.legal.persistence;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import za.ac.alis.core.persistence.SummaryReport;
import za.ac.alis.core.enums.RiskLevel;
import za.ac.alis.core.projections.ReportInfoProjection;
import za.ac.alis.core.projections.RiskStatProjection;
import static za.ac.alis.core.queries.AdminDashboardQueries.FIND_RECENT_REPORTS;
import static za.ac.alis.core.queries.AdminDashboardQueries.RISK_DISTRIBUTION;

@Repository
public interface SummaryReportRepository extends JpaRepository<SummaryReport, Long> {

    long countByRiskLevel(RiskLevel riskLevel);

    @Query(FIND_RECENT_REPORTS)
    List<ReportInfoProjection> findRecentReports(Pageable pageable);

    @Query(RISK_DISTRIBUTION)
    List<RiskStatProjection> findRiskDistribution();

    // Fetch all reports for a document (should return 0 or 1 after the pipeline redesign)
    List<SummaryReport> findByDocumentDocumentId(Long documentId);

    @EntityGraph(attributePaths = { "document", "document.client", "client", "lawRule", "lawRule.act" })
    List<SummaryReport> findByDocumentDocumentIdOrderByGeneratedAtDesc(Long documentId);

    // Fetch the single report for a document
    @EntityGraph(attributePaths = { "document", "document.client", "client", "lawRule", "lawRule.act" })
    Optional<SummaryReport> findFirstByDocument_DocumentId(Long documentId);

    @EntityGraph(attributePaths = { "document", "document.client", "client", "lawRule", "lawRule.act" })
    Optional<SummaryReport> findById(Long reportId);

    @EntityGraph(attributePaths = { "document", "document.client", "client", "lawRule", "lawRule.act" })
    @Query("SELECT r FROM SummaryReport r WHERE r.reportId = :reportId")
    Optional<SummaryReport> findByIdWithRelations(Long reportId);

    List<SummaryReport> findByClientClientId(Long clientId);

    /**
     * Deletes any existing report(s) for the given document.
     * Called before saving a fresh report to guarantee 1-per-document.
     */
    @Modifying
    @Transactional
    @Query("DELETE FROM SummaryReport r WHERE r.document.documentId = :documentId")
    void deleteByDocument_DocumentId(Long documentId);

   


    @Transactional(readOnly = true)   // ← Add this
    @Query("""
        SELECT r FROM SummaryReport r
        JOIN FETCH r.document d
        JOIN FETCH d.client c
        LEFT JOIN FETCH r.lawRule lr
        LEFT JOIN FETCH lr.act a
        WHERE c.clientId = :clientId
        ORDER BY r.generatedAt DESC
    """)
    List<SummaryReport> findReportsByClientIdEager(@Param("clientId") Long clientId);

    // Also improve the one used in AI pipeline if it exists
    @Transactional(readOnly = true)
    @Query("""
        SELECT r FROM SummaryReport r
        JOIN FETCH r.document d
        LEFT JOIN FETCH r.lawRule lr
        LEFT JOIN FETCH lr.act a
        WHERE r.document.documentId = :documentId
        ORDER BY r.generatedAt DESC
    """)
    List<SummaryReport> findByDocumentIdWithRelations(@Param("documentId") Long documentId);

}
